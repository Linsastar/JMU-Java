public interface Mysort {
    public void sortBy();
}
