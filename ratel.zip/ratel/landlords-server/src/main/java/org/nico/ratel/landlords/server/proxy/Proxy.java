package org.nico.ratel.landlords.server.proxy;

public interface Proxy {

    void start(int port) throws InterruptedException;

}
