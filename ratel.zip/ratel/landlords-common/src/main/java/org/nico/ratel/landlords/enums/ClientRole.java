package org.nico.ratel.landlords.enums;

public enum ClientRole {

	PLAYER,

	ROBOT

}
