package org.nico.ratel.landlords.enums;

public enum ClientStatus {

	TO_CHOOSE,

	NO_READY,

	READY,

	WAIT,

	CALL_LANDLORD,

	PLAYING


}
