package org.nico.ratel.landlords.utils;

public class RegxUtils {

//	private final static String POKER_SELECT_REGX = "^[2-9]"

//	public static isRegularPokerSelect(String line) {
//		123456789t
//	}
}
