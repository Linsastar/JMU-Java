package org.nico.ratel.landlords.enums;

public enum ClientType {

	LANDLORD,

	PEASANT

}
