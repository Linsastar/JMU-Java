import javax.swing.*;
import java.awt.*;

public class MainInterface {
    public static void main(String[] args) {
        MainFrame frame=new MainFrame();
    }
}
